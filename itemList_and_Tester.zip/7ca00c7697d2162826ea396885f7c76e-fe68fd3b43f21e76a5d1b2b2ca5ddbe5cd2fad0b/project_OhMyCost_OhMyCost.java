package project_OhMyCost;

public class OhMyCost {
    public static void main(String[] args){
        itemList list1 = new itemList();
        list1.addType("Food");
        list1.addType("Bus");
        list1.addType("Other");
        list1.showTypeList(); // [Food,Bus,Other]
        System.out.println();

        list1.changeTypeByIndex(3,"Fee"); // at index 3 change to "Fee"
        list1.showTypeList(); // [Food,Bus,Fee]
        System.out.println();

        list1.removeType("Bus");
        list1.showTypeList();// [Food,Fee]
        System.out.println();

        list1.showType("Bus");
        System.out.println(); // [Food,Fee] -> there is no Bus

        list1.addType("electricBill");
        list1.changeTypeByWord("Fee","waterBill");
        list1.showTypeList();// [Food,waterBill,electricBill]
        System.out.println();

        System.out.println("type of select(ArrayList) :");
        list1.showTypeAll();
    }
}
