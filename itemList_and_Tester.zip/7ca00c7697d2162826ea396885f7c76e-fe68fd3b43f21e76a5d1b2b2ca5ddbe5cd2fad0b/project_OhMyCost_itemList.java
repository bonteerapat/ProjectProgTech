package project_OhMyCost;

import java.util.ArrayList;

// ArrayList:select   =>  to operate types in select(ArrayList)
public class itemList {
    private ArrayList<String> typeList; // choose
    public itemList(){
        typeList = new ArrayList<>();
    }
    // to add type in select
    public void addType(String word_type){
        typeList.add(word_type);
    }
    // to change type by using index of current type and change to new type
    public void changeTypeByIndex(int index,String word_type){
        for(int i=0;i<typeList.size();i++){
            if(index == (i+1)){
                typeList.set(i,word_type);
            }
        }
    }
    // to change type by type to type : change current type to new type
    public void changeTypeByWord(String word_type,String new_type){
        for(int i=0;i<typeList.size();i++){
            if(word_type.equals(typeList.get(i))){
                typeList.set(i,new_type);
            }
        }
    }
    // to remove type in select(ArrayList)
    public void removeType(String word_type){
        for(int i=0;i<typeList.size();i++){
            if(word_type.equals(typeList.get(i))){
                typeList.remove(typeList.get(i));
            }
        }
    }
    // to clear all types in select(ArrayList)
    public void clearTypeAll(){
        typeList.clear();
    }
    // to show all select(ArrayList) : [type1,type2,...]
    public void showTypeList(){
        System.out.println(typeList);
    }
    // to show one type and check that type is contained in select(ArrayList)
    public void showType(String word_type){
        if(typeList.contains(word_type)){
            System.out.println(word_type);
        }else{
            System.out.println("there is no " + word_type + " here");
        }
    }
    // to show all type that are contained in select(ArrayList)
    public void showTypeAll(){
        for(int i=0;i<typeList.size();i++){
            System.out.println(typeList.get(i));
        }
    }
}
